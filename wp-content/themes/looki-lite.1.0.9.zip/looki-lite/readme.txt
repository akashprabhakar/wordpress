Looki lite WordPress Theme
---------------------

Looki lite is a great and clean free WordPress blog theme, with a awesome scrollable sidebar, optimized for the mobile devices and based on Bootstrap framework. The theme support all modern browsers like Firefox, Chrome, Safari, Opera and Internet Explorer 8, 9 and 10 and uses the most modern technologies like Html5 and Css3.


Created by ThemeinProgress, http://www.themeinprogress.com 
Demo: http://www.wpinprogress.com/demo/looki

Instruction
-------

The sidebar of Looki Lite is into the scrollable sidebar and any widget will be loaded into this area. For view the widgets is necessary open the scrollable sidebar, from the button in the upper right.


License
-------
Looki lite is licensed under GNU General Public License v3.


Credits
-------

/** IMAGES **/

- Photos in the demo

-- Background image by Pixabay: http://pixabay.com/it/sfocatura-sfocato-luci-notte-bokeh-205379/

-- Featured image in the post by Gratisography: http://www.gratisography.com/pictures/63.jpg

--- Both images licensed under CC0 License (Compatible with GNU General Public License v3)

- Patters

-- By Theme in Progress - http://www.themeinprogress.com

--- Licensed under GNU General Public License v3.

/** ICONS **/

- Font Awesome

-- By Dave Gandy - http://fortawesome.github.io/Font-Awesome/

--- Font License under SIL OFL 1.1 - http://scripts.sil.org/OFL ( Applies to all desktop and webfont files in the following directory: /sueva/fonts/ )
--- Code License under MIT License - http://opensource.org/licenses/mit-license.html ( Applies to the font-awesome.min.css file in /sueva/css/ )
--- Brand Icons - All brand icons are trademarks of their respective owners. The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.

/** FONTS **/

- Google Web Fonts (Fjalla One and Roboto Slab)

-- By Google - http://google.com

--- Fjalla One Font by Sorkin Type Co, Licensed under SIL Open Font License (OFL)
http://www.google.com/fonts/specimen/Fjalla+One

--- Roboto Slab Font by Christian Robertson, Licensed under Apache License, Version 2.0 
https://www.google.com/fonts/specimen/Roboto+Slab

/** FRAMEWORK **/

- Twitter Bootstrap

-- By Twitter Bootstrap - http://getbootstrap.com/2.3.2/

--- Licensed under Apache License v2.0

/** JQUERY **/

- Jquery

-- By Jquery - https://jquery.org

--- Licensed under MIT License

- Jquery UI

-- By Jquery - http://jqueryui.com/

--- Licensed under MIT License 

- Jquery Easing:

-- By George McGinley Smith - http://gsgd.co.uk/sandbox/jquery/easing/

--- Licensed under BSD License

/* VARIOUS */

- jQuery.ScrollTo

-- By Ariel Flesler - http://flesler.blogspot.com

--- Licensed under dual licensed, MIT and GPL

- Pretty Photo:

-- By Pretty Photo - http://www.no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/

--- Licensed under GPLv2 or Creative Commons 2.5 license